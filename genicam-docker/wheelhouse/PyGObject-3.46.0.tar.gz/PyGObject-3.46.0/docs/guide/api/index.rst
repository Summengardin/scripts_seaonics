=============
API Reference
=============

.. toctree::
    :titlesonly:
    :maxdepth: 1

    api
    basic_types
    flags_enums
    gobject
    error_handling
