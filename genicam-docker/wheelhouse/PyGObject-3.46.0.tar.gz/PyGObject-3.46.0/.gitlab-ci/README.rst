The images are available at
https://gitlab.gnome.org/GNOME/pygobject/container_registry
